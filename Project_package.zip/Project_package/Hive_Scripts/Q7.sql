select year, COUNT(year) as number_of_applications from h1b_final group by year order by year;
